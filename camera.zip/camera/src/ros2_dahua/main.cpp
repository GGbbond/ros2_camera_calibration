#include<iostream>
#include"cameraStart.h"
#include"video.h"
#include<opencv2/opencv.hpp>
#include<rclcpp/rclcpp.hpp>
using namespace std;


int main(int argc, char * argv[])
{
     rclcpp::init(argc,argv);  

 
     shared_ptr<CameraStart> cameraStart= make_shared<CameraStart>();
       cameraStart->CameraGetStream(cameraStart);

    
    
    rclcpp::shutdown();
    return 0;
}

