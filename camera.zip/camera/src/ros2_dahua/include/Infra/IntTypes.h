//
//  "$Id: IntTypes.h 5985 2016-05-04 07:00:10Z zhang_xiulang $"
//
//  Copyright (c)1992-2007, ZheJiang Dahua Technology Stock CO.LTD.
//  All Rights Reserved.
//
//	Description:
//	Revisions:		Year-Month-Day  SVN-Author  Modification
//

#include "Types/IntTypes.h"