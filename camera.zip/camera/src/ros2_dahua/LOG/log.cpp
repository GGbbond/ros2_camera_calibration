#include "log.h"

LOG::LOG(bool is_create,bool print,bool log)
{
    this->is_print=print;
    this->is_log=log;
    if(is_create)
    {
//        cout<<"默认"<<endl;
        INIT_LOG(this->is_log);
    }
    else
    {
//        cout<<"自定义"<<endl;
    }
}

void LOG::get_mark(string message)
{
    this->file_message=message;
}
void LOG::INIT_LOG(bool log)
{
     this->is_log=log;
     if(!this->file_message.empty())
         this->file_message="("+this->file_message+")";
     if(this->creat_file())//创建日志文件
     {
         this->success("Success log file.\n");
         this->success(" Log file path: \n \""+log_path+"\"\n");
     }
}


steady_clock::time_point LOG::get_time_point()//获取当前时钟
{
    return steady_clock::now();
}

double LOG::calculation_time_difference(steady_clock::time_point start,steady_clock::time_point end)//计算时间差
{
    duration<double>time_span=duration_cast<duration<double>>(end-start);
    return (double)time_span.count();
}
double LOG::calculation_time_difference(steady_clock::time_point start)//计算与当前时间差
{
    steady_clock::time_point end= this->get_time_point();//获取当前时钟
    duration<double>time_span=duration_cast<duration<double>>(end-start);
    return (double)time_span.count();
}



time_t LOG::get_timestamp()//获取当前时间戳
{
    time_t timeReal;
    return time(&timeReal);
}

bool LOG::get_time()
{
    time_t timeReal =this->get_timestamp()+8*3600;
    tm* t =gmtime(&timeReal);
    this->timing.year=t->tm_year+1900;
    this->timing.month=t->tm_mon+1;
    this->timing.day=t->tm_mday;
    this->timing.hour=t->tm_hour;
    this->timing.min=t->tm_min;
    this->timing.sec=t->tm_sec;
    return true;
}

string LOG::transfer_time(bool actively_seek)//传递时间
{
    this->get_time();//更新时间
    string time_text=to_string(this->timing.year)+"-"+to_string(this->timing.month)+"-"+to_string(this->timing.day);
    if(actively_seek)//主动获取
        time_text+=" "+to_string(this->timing.hour)+":"+to_string(this->timing.min)+":"+to_string(this->timing.sec);
    else
        time_text+="-"+to_string(this->timing.hour)+"-"+to_string(this->timing.min)+"-"+to_string(this->timing.sec);
    return time_text;
}

bool LOG::creat_file()//创建日志文件
{
    if(is_log)
    {
        this->get_time();//更新时间
        /*------------------------------获取日志文件名--------------------------------------------------------------*/
        log_name=to_string(this->timing.year)+"-"+to_string(this->timing.month)+"-"+to_string(this->timing.day);
        log_name+="-"+to_string(this->timing.hour)+"-"+to_string(this->timing.min)+this->file_message+".txt";
        log_path=LOG_PATH+log_name;
        /*-------------------------------------------------------------------------------------------------------*/
        this->LogFile.open(log_path,ios::out);
        if(this->LogFile.is_open())
        {
            return true;
        }
        else
        {
            this->is_log=false;
            this->error("Failed to create a log file!\n");
            if(this->is_print==false)this->is_print=true;
            return false;
        }
    }
    else
    {
        if(this->is_print==false)this->is_print=true;
        this->success("No logging.\n");
        return false;
    }
}

void LOG::error(string text,bool is_printf,bool is_time)
{
    string film_time;
    if(is_time)
    {
        this->get_time();//更新时间
        film_time+="["+to_string(this->timing.hour)+":"+to_string(this->timing.min)+":"+to_string(this->timing.sec)+"]";
    }
    film_time+="ERROR: "+text;
    if(this->is_log)
        LogFile<<film_time<<endl;
    if(this->is_print&&is_printf)
        cout<<film_time<<endl;
}
void LOG::success(string text,bool is_printf,bool is_time)
{
    string film_time;
    if(is_time)
    {
        this->get_time();//更新时间
        film_time+="["+to_string(this->timing.hour)+":"+to_string(this->timing.min)+":"+to_string(this->timing.sec)+"]";
    }
    film_time+="SUCCESS: "+text;
    if(this->is_log)
        LogFile<<film_time<<endl;
    if(this->is_print&&is_printf)
        cout<<film_time<<endl;

}
