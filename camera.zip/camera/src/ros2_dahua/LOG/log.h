﻿#ifndef LOG_H
#define LOG_H

//引入所需路径所在的头文件(LOG_PATH)
#define LOG_PATH "/home/hsc/基本框架说明(2022.2.12)/FeiHuVision _MY_new_2/LOG/RedologFiles/"

#include<fstream>
#include<iostream>
#include<string>
#include<time.h>
#include <chrono>
using namespace std;
using namespace std::chrono;


class LOG
{
public:
    LOG(bool is_create =false,bool print=true,bool log=true);
    struct system_time
    {
      int year;
      int month;
      int day;
      int hour;
      int min;
      int sec;
    };
    bool creat_file();//创建日志文件
    void get_mark(string message);
    void INIT_LOG(bool log=true);
    void error(string text,bool is_printf = true,bool is_time=false);
    void success(string text,bool is_printf = true,bool is_time=false);
    bool get_time();
    string transfer_time(bool actively_seek=false);//传递时间
    time_t get_timestamp();//获取当前时间戳

    steady_clock::time_point get_time_point();//获取当前时钟
    double calculation_time_difference(steady_clock::time_point start,steady_clock::time_point end);//计算时间差
    double calculation_time_difference(steady_clock::time_point start);//计算与当前时间差

private:
    bool is_print,is_log;
    system_time timing;
    string log_name;
    string file_message;
    string log_path;
    ofstream LogFile;
};
#endif // LOG_H
