#ifndef CAMERA01_H
#define CAMERA01_H

#include<opencv2/opencv.hpp>
#include<sensor_msgs/msg/image.hpp>
#include<std_msgs/msg/header.hpp>
#include<rclcpp/rclcpp.hpp>

#include"video.h"
#include<vector>
#include"log.h"
#endif // CAMERA01_H
#define VideoCheck_NUM 5  //搜索相机的次数
#define VideoOpen_NUM 3 //初始化相机的次数
using namespace cv;
using namespace std;
using std::placeholders::_1;

class CameraStart : public rclcpp::Node
{
public:
    CameraStart()  : Node("publisher_img")
    {
        log.get_mark("计算帧数");
        log.INIT_LOG(true);

          pub_img=this->create_publisher<sensor_msgs::msg::Image>("image_raw",10);
      timer_ = this->create_wall_timer(50ms, std::bind(&CameraStart::timer_callback, this));

    }

    bool ConectCameras();      //开始连接相机
    void CameraGetStream(shared_ptr<CameraStart> cameraStart);    //开始拉流
    void CameragetImage();     //取图线程
    void CameragetAmong();     //中间传递图片的线程
    void CameraImageProcess(); //处理线程



private:
    LOG log;
    steady_clock::time_point start;  //时间

    Video camera;              //定义Video类对象
    int VideoCheck_LOSTUM = 1; //记录搜索相机失败的次数
    int VideoOpen_LOSTUM = 1; //记录初始化相机失败的次数
    int ENTER = 0;            //设定进入的模块


     int flag_imag=1;           //取帧图片的数量
     bool work1_flag = false;  //处理图片线程启动的标志
     bool work2_flag = false;  //获取到图片的标志


     double fps;          //帧率
     double total_time;   //总时间

      Mat src;           //获取的帧图片
      Mat new_src;       //


     rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr pub_img;
        rclcpp::TimerBase::SharedPtr timer_;
   void timer_callback();
};
