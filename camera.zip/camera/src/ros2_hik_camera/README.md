# ros2_hik_camera

A ROS2 packge for Hikvision USB3.0 industrial camera

## Usage

```

. install/setup.bash
ros2 launch hik_camera hik_camera.launch.py
```

## Params

- exposure_time
- gain

改曝光时间
hik_camera_node.cpp   第139行   。。。
camera_params.yaml



